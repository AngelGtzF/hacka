-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema HackOmens
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema HackOmens
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `HackOmens` DEFAULT CHARACTER SET utf8 ;
USE `HackOmens` ;

-- -----------------------------------------------------
-- Table `HackOmens`.`ActoJuridico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`ActoJuridico` (
  `idActoJuridico` INT NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`idActoJuridico`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`ControlInternoAsignado`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`ControlInternoAsignado` (
  `idControlInternoAsignado` INT NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idControlInternoAsignado`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`Sector`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`Sector` (
  `idSector` INT NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idSector`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`TitularActoJuridico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`TitularActoJuridico` (
  `idTitularActoJuridico` INT NOT NULL,
  `nombres` VARCHAR(100) NOT NULL,
  `primerApellido` VARCHAR(150) NOT NULL,
  `segundoApellido` VARCHAR(150) NOT NULL,
  `razonSocial` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`idTitularActoJuridico`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`FechaVigenciaActo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`FechaVigenciaActo` (
  `idFechaVigenciaActo` INT NOT NULL,
  `inicioVigencia` VARCHAR(45) NOT NULL,
  `terminoVigencia` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idFechaVigenciaActo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`ClausulasTerminosCondiciones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`ClausulasTerminosCondiciones` (
  `idClausulasTerminosCondiciones` INT NOT NULL,
  `nombre` VARCHAR(400) NULL,
  PRIMARY KEY (`idClausulasTerminosCondiciones`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`Montos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`Montos` (
  `idMontos` INT NOT NULL,
  `montoRecursoTotal` VARCHAR(100) NULL,
  `montoRecursoTotalPagado` VARCHAR(100) NULL,
  PRIMARY KEY (`idMontos`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`AreasDeInformacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`AreasDeInformacion` (
  `idAreasDeInformacion` INT NOT NULL,
  `nombre` VARCHAR(45) NULL,
  PRIMARY KEY (`idAreasDeInformacion`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`Hipervinculos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`Hipervinculos` (
  `idHipervinculos` INT NOT NULL,
  `contratoPermisoLicencia` VARCHAR(100) NULL,
  `documentoGastoAnual` VARCHAR(100) NULL,
  `contratoPlurianual` VARCHAR(100) NULL,
  `convenioModificatorio` VARCHAR(45) NULL,
  PRIMARY KEY (`idHipervinculos`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`Notas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`Notas` (
  `idNotas` INT NOT NULL,
  `nota` LONGTEXT NULL,
  PRIMARY KEY (`idNotas`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`InformacionGeneral`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`InformacionGeneral` (
  `idInformacionGeneral` INT NOT NULL,
  `ejercicio` YEAR NOT NULL,
  `fechaInicioInforme` DATE NOT NULL,
  `fechaTerminoInforme` DATE NOT NULL,
  `ActoJuridico_id` INT NOT NULL,
  `ControlInternoAsignado_id` INT NOT NULL,
  `objetoRealizacionActoJ` VARCHAR(45) NULL COMMENT ' Objeto de La Realización Del Acto Jurídico',
  `razonActoJuridico` VARCHAR(400) NULL COMMENT ' Fundamento Jurídico por El Cual Se Llevó a Cabo El Acto',
  `Sector_id` INT NOT NULL,
  `TitularActoJuridico_id` INT NOT NULL,
  `fechaVigenciaActo_id` INT NOT NULL,
  `clausulasTerminosCondiciones_idClausulasTerminosCondiciones` INT NOT NULL,
  `Montos_idMontos` INT NOT NULL,
  `AreasDeInformacion_idAreasDeInformacion` INT NOT NULL,
  `Hipervinculos_idHipervinculos` INT NOT NULL,
  `Notas_idNotas` INT NOT NULL,
  `fechaValidacion` DATE NULL,
  `fechaActualizacion` DATE NULL,
  PRIMARY KEY (`idInformacionGeneral`),
  INDEX `fk_InformacionGeneral_ActoJuridico_idx` (`ActoJuridico_id` ASC) ,
  INDEX `fk_InformacionGeneral_ControlInternoAsignado1_idx` (`ControlInternoAsignado_id` ASC) ,
  INDEX `fk_InformacionGeneral_Sector1_idx` (`Sector_id` ASC) ,
  INDEX `fk_InformacionGeneral_TitularActoJuridico1_idx` (`TitularActoJuridico_id` ASC) ,
  INDEX `fk_InformacionGeneral_fechaVigenciaActo1_idx` (`fechaVigenciaActo_id` ASC) ,
  INDEX `fk_InformacionGeneral_clausulasTerminosCondiciones1_idx` (`clausulasTerminosCondiciones_idClausulasTerminosCondiciones` ASC) ,
  INDEX `fk_InformacionGeneral_Montos1_idx` (`Montos_idMontos` ASC) ,
  INDEX `fk_InformacionGeneral_AreasDeInformacion1_idx` (`AreasDeInformacion_idAreasDeInformacion` ASC) ,
  INDEX `fk_InformacionGeneral_Hipervinculos1_idx` (`Hipervinculos_idHipervinculos` ASC) ,
  INDEX `fk_InformacionGeneral_Notas1_idx` (`Notas_idNotas` ASC) ,
  CONSTRAINT `fk_InformacionGeneral_ActoJuridico`
    FOREIGN KEY (`ActoJuridico_id`)
    REFERENCES `HackOmens`.`ActoJuridico` (`idActoJuridico`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_ControlInternoAsignado1`
    FOREIGN KEY (`ControlInternoAsignado_id`)
    REFERENCES `HackOmens`.`ControlInternoAsignado` (`idControlInternoAsignado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_Sector1`
    FOREIGN KEY (`Sector_id`)
    REFERENCES `HackOmens`.`Sector` (`idSector`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_TitularActoJuridico1`
    FOREIGN KEY (`TitularActoJuridico_id`)
    REFERENCES `HackOmens`.`TitularActoJuridico` (`idTitularActoJuridico`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_fechaVigenciaActo1`
    FOREIGN KEY (`fechaVigenciaActo_id`)
    REFERENCES `HackOmens`.`FechaVigenciaActo` (`idFechaVigenciaActo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_clausulasTerminosCondiciones1`
    FOREIGN KEY (`clausulasTerminosCondiciones_idClausulasTerminosCondiciones`)
    REFERENCES `HackOmens`.`ClausulasTerminosCondiciones` (`idClausulasTerminosCondiciones`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_Montos1`
    FOREIGN KEY (`Montos_idMontos`)
    REFERENCES `HackOmens`.`Montos` (`idMontos`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_AreasDeInformacion1`
    FOREIGN KEY (`AreasDeInformacion_idAreasDeInformacion`)
    REFERENCES `HackOmens`.`AreasDeInformacion` (`idAreasDeInformacion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_Hipervinculos1`
    FOREIGN KEY (`Hipervinculos_idHipervinculos`)
    REFERENCES `HackOmens`.`Hipervinculos` (`idHipervinculos`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_Notas1`
    FOREIGN KEY (`Notas_idNotas`)
    REFERENCES `HackOmens`.`Notas` (`idNotas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`ResponsablesInstrumentacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`ResponsablesInstrumentacion` (
  `idResponsablesInstrumentacion` INT NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idResponsablesInstrumentacion`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`InformeTieneResponsablesInstrumentacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`InformeTieneResponsablesInstrumentacion` (
  `idInformeTieneResponsablesInstrumentacion` INT NOT NULL,
  `InformacionGeneral_id` INT NOT NULL,
  `responsablesInstrumentacion_id` INT NOT NULL,
  PRIMARY KEY (`idInformeTieneResponsablesInstrumentacion`, `InformacionGeneral_id`, `responsablesInstrumentacion_id`),
  INDEX `fk_InformacionGeneral_has_responsablesInstrumentacion_respo_idx` (`responsablesInstrumentacion_id` ASC),
  INDEX `fk_InformacionGeneral_has_responsablesInstrumentacion_Infor_idx` (`InformacionGeneral_id` ASC) ,
  CONSTRAINT `fk_InformacionGeneral_has_responsablesInstrumentacion_Informa1`
    FOREIGN KEY (`InformacionGeneral_id`)
    REFERENCES `HackOmens`.`InformacionGeneral` (`idInformacionGeneral`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_InformacionGeneral_has_responsablesInstrumentacion_respons1`
    FOREIGN KEY (`responsablesInstrumentacion_id`)
    REFERENCES `HackOmens`.`ResponsablesInstrumentacion` (`idResponsablesInstrumentacion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`Leyes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`Leyes` (
  `idLeyes` INT NOT NULL,
  `nombre` LONGTEXT NOT NULL,
  PRIMARY KEY (`idLeyes`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HackOmens`.`ClausulasTerminosCondicionesTieneLeyes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `HackOmens`.`ClausulasTerminosCondicionesTieneLeyes` (
  `clausulasTerminosCondiciones_id` INT NOT NULL,
  `Leyes_id` INT NOT NULL,
  `idClausulasTerminosCondicionesTieneLeyes` VARCHAR(45) NULL,
  PRIMARY KEY (`clausulasTerminosCondiciones_id`, `Leyes_id`),
  INDEX `fk_clausulasTerminosCondiciones_has_Leyes_Leyes1_idx` (`Leyes_id` ASC) ,
  INDEX `fk_clausulasTerminosCondiciones_has_Leyes_clausulasTerminos_idx` (`clausulasTerminosCondiciones_id` ASC) ,
  CONSTRAINT `fk_clausulasTerminosCondiciones_has_Leyes_clausulasTerminosCo1`
    FOREIGN KEY (`clausulasTerminosCondiciones_id`)
    REFERENCES `HackOmens`.`ClausulasTerminosCondiciones` (`idClausulasTerminosCondiciones`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_clausulasTerminosCondiciones_has_Leyes_Leyes1`
    FOREIGN KEY (`Leyes_id`)
    REFERENCES `HackOmens`.`Leyes` (`idLeyes`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
